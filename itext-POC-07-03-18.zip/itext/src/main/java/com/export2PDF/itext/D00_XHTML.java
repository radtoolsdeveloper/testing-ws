/*
package com.export2PDF.itext;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;

import org.jsoup.Jsoup;

*//**
 * Converts an HTML file into an XTHML file.
 *//*
public class D00_XHTML {

	*//** The name of a HTML file *//*
	public static final String WALDEN = "results/resources/html/pivot_HTML_data.html";
	*//** The name of a HTML file *//*
	public static final String THOREAU = "results/resources/html/output_pivot_HTML_data.html";

	*//** The main method. *//*
	public static void main(String[] args) throws IOException {
		tidyUp(WALDEN);
		tidyUp(THOREAU);
	}
	
	public static void createPdf() throws IOException {
		D00_XHTML.tidyUp(D00_XHTML.WALDEN);
		//D00_XHTML.tidyUp(D00_XHTML.THOREAU);
	}

	public static void tidyUp(String path) throws IOException {
		File html = new File(path);
		byte[] xhtml = Jsoup.parse(html, "US-ASCII").html().getBytes();
		File dir = new File("results/xml");
		dir.mkdirs();
		FileOutputStream fos = new FileOutputStream(new File(dir, html.getName().substring(0, html.getName().length()-5)));
		fos.write(xhtml);
		fos.close();
	}
}
*/