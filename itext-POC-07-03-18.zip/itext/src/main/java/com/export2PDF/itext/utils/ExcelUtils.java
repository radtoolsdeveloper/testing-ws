package com.export2PDF.itext.utils;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.Reader;
import java.sql.Clob;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Types;
import java.util.Map;

public class ExcelUtils {
	public static String getValue(String columnName, Map<String, Integer> columnNamesTypes, ResultSet rs)
			throws SQLException {
		boolean b;
		long l;
		double d;
		String s;
		String t;
		String value = null;
		switch (columnNamesTypes.get(columnName)) {
		case Types.INTEGER:
			l = rs.getInt(columnName);
			value = String.valueOf(l);
			break;

		case Types.BIGINT:
			l = rs.getLong(columnName);
			value = String.valueOf(l);
			break;

		case Types.TINYINT:
		case Types.SMALLINT:
			l = rs.getShort(columnName);
			value = String.valueOf(l);
			break;

		case Types.DECIMAL:
		case Types.NUMERIC:
			value = String.valueOf((rs.getBigDecimal(columnName)));
			break;

		case Types.FLOAT:
		case Types.REAL:
		case Types.DOUBLE:
			value = String.valueOf(rs.getDouble(columnName));

			break;

		case Types.NVARCHAR:
		case Types.VARCHAR:
		case Types.LONGNVARCHAR:
		case Types.LONGVARCHAR:
			value = String.valueOf(rs.getString(columnName));

			break;

		case Types.BOOLEAN:
		case Types.BIT:
			value = String.valueOf(rs.getBoolean(columnName));

			break;

		case Types.BINARY:
		case Types.VARBINARY:
		case Types.LONGVARBINARY:
			value = String.valueOf(rs.getBytes(columnName));
			break;

		case Types.DATE:
			// provider.defaultSerializeDateValue(rs.getDate(column), jsonGen);

			value = String.valueOf(rs.getDate(columnName));
			break;

		case Types.TIMESTAMP:
			// provider.defaultSerializeDateValue(rs.getTimestamp(column),
			// jsonGen);
			value = String.valueOf(rs.getDate(columnName));
			break;
		/*
		 * case Types.TIMESTAMP_WITH_TIMEZONE: if (rs.wasNull()) {
		 * jsonGen.writeNull(); } else {
		 * jsonGen.writeString(rs.getDate(index).toString()); } break;
		 */
		case Types.BLOB:
			/*
			 * Blob blob = rs.getBlob(index);
			 * provider.defaultSerializeValue(blob.getBinaryStream(), jsonGen);
			 * blob.free();
			 */
			/*
			 * try(BufferedReader reader = new BufferedReader(new
			 * InputStreamReader(rs.getBlob(index).getBinaryStream()))){
			 * 
			 * StringBuilder out = new StringBuilder(); String line; while
			 * ((line = reader.readLine()) != null) { out.append(line); }
			 * logger.debug(out.toString()); //Prints the string content read
			 * from input stream reader.close();
			 * jsonGen.writeString(out.toString()); }
			 */

			value = "BLOB NOT SUPPORTED";
			// logger.debug(rs.getBlob(index).getBinaryStream());
			/*
			 * s = rs.getString(index); if (rs.wasNull()) {
			 * jsonGen.writeString("null"); } else { jsonGen.writeString(s); }
			 */
			break;

		case Types.CLOB:

			StringBuilder sb = new StringBuilder();
			Clob clob = rs.getClob(columnName);
			if (clob == null) {
				value = null;
				break;
			}
			try {
				Reader reader = clob.getCharacterStream();
				BufferedReader br = new BufferedReader(reader);

				String line;
				while (null != (line = br.readLine())) {
					sb.append(line);
				}
				br.close();
				int maxLength = 1000;
				int length = sb.toString().length();
				String data = length > maxLength ? sb.toString().subSequence(0, maxLength) + "...." : sb.toString();
				value = data;
			} catch (SQLException e) {
				// handle this exception
			} catch (IOException e) {
				// handle this exception
			}
			break;
		case Types.ARRAY:
			value = "ARRAY NOT SUPPORTED";
			// throw new
			// RuntimeException("ResultSetSerializer not yet implemented for SQL
			// type ARRAY");
			break;
		case Types.STRUCT:
			value = "STRUCT NOT SUPPORTED";
			break;
		// throw new
		// RuntimeException("ResultSetSerializer not yet implemented for SQL
		// type STRUCT");
		case Types.DISTINCT:
			value = "DISTINCT NOT SUPPORTED";
			break;
		// throw new
		// RuntimeException("ResultSetSerializer not yet implemented for SQL
		// type DISTINCT");
		case Types.REF:
			value = "REF NOT SUPPORTED";
			break;
		// throw new
		// RuntimeException("ResultSetSerializer not yet implemented for SQL
		// type REF");
		case Types.JAVA_OBJECT:
		default:
			value = String.valueOf(rs.getObject(columnName));
			break;
		}

		return value;
	}
}
