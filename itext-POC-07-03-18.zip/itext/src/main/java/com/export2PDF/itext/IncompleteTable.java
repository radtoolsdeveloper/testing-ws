/**
 * Example written by Bruno Lowagie
 */
package com.export2PDF.itext;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;

import org.springframework.boot.SpringApplication;

import com.export2PDF.itext.cellAndTableWidths.ColumnWidthExample;
import com.export2PDF.itext.common.CommonConstants;
import com.itextpdf.text.Document;
import com.itextpdf.text.DocumentException;
import com.itextpdf.text.PageSize;
import com.itextpdf.text.pdf.PdfPTable;
import com.itextpdf.text.pdf.PdfWriter;

public class IncompleteTable {
	public static final String DEST = "results/tables/incomplete_table.pdf";

	
	public static void main(String[] args) throws IOException, DocumentException {
		//new IncompleteTable().createPdf();
		//new D00_XHTML().createPdf();
		//new ColumnWidthExample().createPdf(CommonConstants.DEST);
		new ColumnWidthExample().createPDF2(CommonConstants.DEST);
		//new ColumnWidthExample().createPdf3(CommonConstants.DEST);
		//new AddOpenAction().manipulatePdf(CommonConstants.SRC, CommonConstants.MANIP_DEST);
		
		//new ColumnWidthExample().newPageExamplePdf(CommonConstants.DEST);
		
		SpringApplication.run(IncompleteTable.class, args);
	}

	public void createPdf() throws IOException, DocumentException {
		File file = new File(IncompleteTable.DEST);
		file.getParentFile().mkdirs();
		Document document = new Document(PageSize.LETTER);
		PdfWriter.getInstance(document, new FileOutputStream(IncompleteTable.DEST));

		document.open();
		PdfPTable table = new PdfPTable(5);
		table.setHeaderRows(1);
		table.setSplitRows(false);
		table.setComplete(false);

		for (int i = 0; i < 70; i++) {
			table.addCell("Header " + i);
		}

		for (int i = 0; i < 500; i++) {
			if (i % 5 == 0) {
				document.add(table);
			}
			table.addCell("Test " + i);
		}

		table.setComplete(true);
		document.add(table);
		document.close();
	}

}