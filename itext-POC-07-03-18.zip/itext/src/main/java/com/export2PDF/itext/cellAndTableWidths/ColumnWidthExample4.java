package com.export2PDF.itext.cellAndTableWidths;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.HashMap;
import java.util.Map;

import com.export2PDF.itext.common.CommonConstants;
import com.export2PDF.itext.utils.ExcelUtils;
import com.itextpdf.text.BaseColor;
/**
 * This example was written by Bruno Lowagie in answer to the following question:
 * http://stackoverflow.com/questions/26628678/manipulating-witdh-and-height-of-rows-and-cells-in-itextsharp
 */
import com.itextpdf.text.Document;
import com.itextpdf.text.DocumentException;
import com.itextpdf.text.Font;
import com.itextpdf.text.Font.FontFamily;
import com.itextpdf.text.PageSize;
import com.itextpdf.text.Phrase;
import com.itextpdf.text.Rectangle;
import com.itextpdf.text.pdf.GrayColor;
import com.itextpdf.text.pdf.PdfContentByte;
import com.itextpdf.text.pdf.PdfPCell;
import com.itextpdf.text.pdf.PdfPTable;
import com.itextpdf.text.pdf.PdfWriter;

public class ColumnWidthExample4 {


	public void createPDF2(String dest){
		dest = "C:/Users/pradeep.repala/Desktop/results/tables/column_width_example_snippet.pdf";
		Document document = null;
		ResultSetMetaData rsMetaData = null;
		
		//4 columns
		//String stringQuery = "SELECT TOP 1000 * FROM (SELECT ROW_NUMBER() OVER(ORDER BY (SELECT null)) AS RowNum, [AGENCY_CT_AGENTS].[RA_COUNTRY] as 'RA_COUNTRY',[AGENCY_CT_AGENTS].[RA_STATE] as 'RA_STATE',[AGENCY_CT_AGENTS].[RA_STREET] as 'RA_STREET',[AGENCY_CT_AGENTS].[ACC_BSB_NO] as 'ACC_BSB_NO'  FROM [GFOS].[CT_AGENTS].[AGENCY] [AGENCY_CT_AGENTS] inner join [GFOS].[CT_AGENTS].[AGENCY_AC_COMMISSION_2] [AGENCY_AC_COMMISSION_2_CT_AGENTS] on [AGENCY_CT_AGENTS].[AGENCY_NO]=[AGENCY_AC_COMMISSION_2_CT_AGENTS].[AGENCY_NO] GROUP BY [AGENCY_CT_AGENTS].[RA_COUNTRY], [AGENCY_CT_AGENTS].[RA_STATE], [AGENCY_CT_AGENTS].[RA_STREET], [AGENCY_CT_AGENTS].[ACC_BSB_NO]) AS subTable WHERE RowNum > 0 AND RowNum <= 100";
		
		//20 columns
		//String stringQuery = "SELECT TOP 1000 * FROM (SELECT ROW_NUMBER() OVER(ORDER BY (SELECT null)) AS RowNum,[AGENCY_CT_AGENTS].[RA_STATE] as 'RA_STATE',[AGENCY_CT_AGENTS].[RA_STATE] as 'RA_STATE1',[AGENCY_CT_AGENTS].[RA_STATE] as 'RA_STATE2',[AGENCY_CT_AGENTS].[RA_STATE] as 'RA_STATE3',[AGENCY_CT_AGENTS].[RA_STATE] as 'RA_STATE4',[AGENCY_CT_AGENTS].[RA_STATE] as 'RA_STATE5',[AGENCY_CT_AGENTS].[RA_STATE] as 'RA_STATE6',[AGENCY_CT_AGENTS].[RA_STATE] as 'RA_STATE7',[AGENCY_CT_AGENTS].[RA_STATE] as 'RA_STATE8',[AGENCY_CT_AGENTS].[RA_STREET] as 'RA_STREET',[AGENCY_CT_AGENTS].[RA_STREET] as 'RA_STREET1',[AGENCY_CT_AGENTS].[RA_STREET] as 'RA_STREET2',[AGENCY_CT_AGENTS].[RA_STREET] as 'RA_STREET3',[AGENCY_CT_AGENTS].[RA_STREET] as 'RA_STREET4',[AGENCY_CT_AGENTS].[ACC_BSB_NO] as 'ACC_BSB_NO',[AGENCY_CT_AGENTS].[ACC_BSB_NO] as 'ACC_BSB_NO1',[AGENCY_CT_AGENTS].[ACC_BSB_NO] as 'ACC_BSB_NO2',[AGENCY_CT_AGENTS].[ACC_BSB_NO] as 'ACC_BSB_NO3',[AGENCY_CT_AGENTS].[ACC_BSB_NO] as 'ACC_BSB_NO4',[AGENCY_CT_AGENTS].[ACC_BSB_NO] as 'ACC_BSB_NO5'  FROM [GFOS].[CT_AGENTS].[AGENCY] [AGENCY_CT_AGENTS] inner join [GFOS].[CT_AGENTS].[AGENCY_AC_COMMISSION_2] [AGENCY_AC_COMMISSION_2_CT_AGENTS] on [AGENCY_CT_AGENTS].[AGENCY_NO]=[AGENCY_AC_COMMISSION_2_CT_AGENTS].[AGENCY_NO] GROUP BY [AGENCY_CT_AGENTS].[RA_COUNTRY], [AGENCY_CT_AGENTS].[RA_STATE], [AGENCY_CT_AGENTS].[RA_STREET], [AGENCY_CT_AGENTS].[ACC_BSB_NO]) AS subTable WHERE RowNum > 0 AND RowNum <= 100";
		
		//25 columns
		//String stringQuery = "SELECT TOP 1000 * FROM (SELECT ROW_NUMBER() OVER(ORDER BY (SELECT null)) AS RowNum, [AGENCY_CT_AGENTS].[RA_COUNTRY] as 'RA_COUNTRY', [AGENCY_CT_AGENTS].[RA_COUNTRY] as 'RA_COUNTRY2', [AGENCY_CT_AGENTS].[RA_COUNTRY] as 'RA_COUNTRY3', [AGENCY_CT_AGENTS].[RA_COUNTRY] as 'RA_COUNTRY4', [AGENCY_CT_AGENTS].[RA_COUNTRY] as 'RA_COUNTRY5',[AGENCY_CT_AGENTS].[RA_STATE] as 'RA_STATE',[AGENCY_CT_AGENTS].[RA_STATE] as 'RA_STATE1',[AGENCY_CT_AGENTS].[RA_STATE] as 'RA_STATE2',[AGENCY_CT_AGENTS].[RA_STATE] as 'RA_STATE3',[AGENCY_CT_AGENTS].[RA_STATE] as 'RA_STATE4',[AGENCY_CT_AGENTS].[RA_STATE] as 'RA_STATE5',[AGENCY_CT_AGENTS].[RA_STATE] as 'RA_STATE6',[AGENCY_CT_AGENTS].[RA_STATE] as 'RA_STATE7',[AGENCY_CT_AGENTS].[RA_STATE] as 'RA_STATE8',[AGENCY_CT_AGENTS].[RA_STREET] as 'RA_STREET',[AGENCY_CT_AGENTS].[RA_STREET] as 'RA_STREET1',[AGENCY_CT_AGENTS].[RA_STREET] as 'RA_STREET2',[AGENCY_CT_AGENTS].[RA_STREET] as 'RA_STREET3',[AGENCY_CT_AGENTS].[RA_STREET] as 'RA_STREET4',[AGENCY_CT_AGENTS].[ACC_BSB_NO] as 'ACC_BSB_NO',[AGENCY_CT_AGENTS].[ACC_BSB_NO] as 'ACC_BSB_NO1',[AGENCY_CT_AGENTS].[ACC_BSB_NO] as 'ACC_BSB_NO2',[AGENCY_CT_AGENTS].[ACC_BSB_NO] as 'ACC_BSB_NO3',[AGENCY_CT_AGENTS].[ACC_BSB_NO] as 'ACC_BSB_NO4',[AGENCY_CT_AGENTS].[ACC_BSB_NO] as 'ACC_BSB_NO5'  FROM [GFOS].[CT_AGENTS].[AGENCY] [AGENCY_CT_AGENTS] inner join [GFOS].[CT_AGENTS].[AGENCY_AC_COMMISSION_2] [AGENCY_AC_COMMISSION_2_CT_AGENTS] on [AGENCY_CT_AGENTS].[AGENCY_NO]=[AGENCY_AC_COMMISSION_2_CT_AGENTS].[AGENCY_NO] GROUP BY [AGENCY_CT_AGENTS].[RA_COUNTRY], [AGENCY_CT_AGENTS].[RA_STATE], [AGENCY_CT_AGENTS].[RA_STREET], [AGENCY_CT_AGENTS].[ACC_BSB_NO]) AS subTable WHERE RowNum > 0 AND RowNum <= 100";
		
		//25 columns
		//String stringQuery = "SELECT [MARKET_CT_PRODUCTS].[MARKET_ID] as 'MARKET_ID[MARKET]',[SUPPLEMENT_CAT_CT_PRODUCTS].[NAME] as 'NAME',[COMPONENT_CT_BOOKINGS].[BOOKING_NO] as 'BOOKING_NO',[COMPONENT_CT_BOOKINGS].[COMPONENT_NO] as 'COMPONENT_NO',YEAR([CPL_Booking_Agency_CT_BOOKINGS].[STG_UPDATED_DATE]) as 'Year_Of_STG_UPDATED_DATE[CPL_Booking_Agency]',DATEPART(QUARTER,[CPL_Booking_Agency_CT_BOOKINGS].[STG_UPDATED_DATE]) as 'Quarter_Of_STG_UPDATED_DATE[CPL_Booking_Agency]',[CPL_Booking_Agency_CT_BOOKINGS].[BOOKING_STATUS] as 'BOOKING_STATUS',[SERVICE_VERSION_CT_BOOKINGS].[PROD_CODE] as 'PROD_CODE',SUM(CAST([SERVICE_SUP_CT_BOOKINGS].[GROSS_AMT] AS money)) as 'SUM(GROSS_AMT)',SUM(CAST([SERVICE_SUP_CT_BOOKINGS].[NET_AMT] AS money)) as 'SUM(NET_AMT)',[SERVICE_SUP_CT_BOOKINGS].[DESCRIPTION] as 'DESCRIPTION',[SERVICE_SUP_CT_BOOKINGS].[SUP_ID] as 'SUP_ID'  FROM [GFOS].[CT_BOOKINGS].[COMPONENT] [COMPONENT_CT_BOOKINGS] inner join [GFOS].[CT_BOOKINGS].[CPL_Booking_Agency] [CPL_Booking_Agency_CT_BOOKINGS] on [COMPONENT_CT_BOOKINGS].[BOOKING_NO]=[CPL_Booking_Agency_CT_BOOKINGS].[BOOKING_NO] and [COMPONENT_CT_BOOKINGS].[SEASON]=[CPL_Booking_Agency_CT_BOOKINGS].[SEASON] inner join [GFOS].[CT_BOOKINGS].[SERVICE] [SERVICE_CT_BOOKINGS] on [COMPONENT_CT_BOOKINGS].[SEASON]=[SERVICE_CT_BOOKINGS].[SEASON] and [COMPONENT_CT_BOOKINGS].[SERVICE_NO]=[SERVICE_CT_BOOKINGS].[SERVICE_NO] inner join [GFOS].[CT_BOOKINGS].[SERVICE_SUP] [SERVICE_SUP_CT_BOOKINGS] on [SERVICE_CT_BOOKINGS].[SEASON]=[SERVICE_SUP_CT_BOOKINGS].[SEASON] and [SERVICE_CT_BOOKINGS].[CPL_VERSION_NO]=[SERVICE_SUP_CT_BOOKINGS].[VERSION_NO] and [SERVICE_CT_BOOKINGS].[SERVICE_NO]=[SERVICE_SUP_CT_BOOKINGS].[SERVICE_NO] left outer join [GFOS].[CT_PRODUCTS].[SUPPLEMENT_CAT] [SUPPLEMENT_CAT_CT_PRODUCTS] on [SERVICE_SUP_CT_BOOKINGS].[SUP_CAT_ID]=[SUPPLEMENT_CAT_CT_PRODUCTS].[SUP_CAT_ID] inner join [GFOS].[CT_BOOKINGS].[SERVICE_VERSION] [SERVICE_VERSION_CT_BOOKINGS] on [SERVICE_CT_BOOKINGS].[FST_VERSION_NO]=[SERVICE_VERSION_CT_BOOKINGS].[VERSION_NO] and [SERVICE_CT_BOOKINGS].[SEASON]=[SERVICE_VERSION_CT_BOOKINGS].[SEASON] and [SERVICE_CT_BOOKINGS].[SERVICE_NO]=[SERVICE_VERSION_CT_BOOKINGS].[SERVICE_NO] inner join [GFOS].[CT_AGENTS].[AGENCY] [AGENCY_CT_AGENTS] on [CPL_Booking_Agency_CT_BOOKINGS].[AGENCY_NO]=[AGENCY_CT_AGENTS].[AGENCY_NO] inner join [GFOS].[CT_PRODUCTS].[MARKET] [MARKET_CT_PRODUCTS] on [AGENCY_CT_AGENTS].[MARKET_ID]=[MARKET_CT_PRODUCTS].[MARKET_ID] WHERE [SUPPLEMENT_CAT_CT_PRODUCTS].[NAME] IN ('Agent Rebate Distributor','Agent Rebate Operator') GROUP BY [MARKET_CT_PRODUCTS].[MARKET_ID], [SUPPLEMENT_CAT_CT_PRODUCTS].[NAME], [COMPONENT_CT_BOOKINGS].[BOOKING_NO], [COMPONENT_CT_BOOKINGS].[COMPONENT_NO], YEAR([CPL_Booking_Agency_CT_BOOKINGS].[STG_UPDATED_DATE]), DATEPART(QUARTER,[CPL_Booking_Agency_CT_BOOKINGS].[STG_UPDATED_DATE]), [CPL_Booking_Agency_CT_BOOKINGS].[BOOKING_STATUS], [SERVICE_VERSION_CT_BOOKINGS].[PROD_CODE], [SERVICE_SUP_CT_BOOKINGS].[DESCRIPTION], [SERVICE_SUP_CT_BOOKINGS].[SUP_ID] ORDER BY [SUPPLEMENT_CAT_CT_PRODUCTS].[NAME] ASC";
		
		//Hierarchies with order by
		//String stringQuery = "SELECT ROW_NUMBER() OVER( ORDER BY [MARKET_CT_PRODUCTS].[MARKET_ID], [SUPPLEMENT_CAT_CT_PRODUCTS].[NAME]) AS RowNum, [MARKET_CT_PRODUCTS].[MARKET_ID] as 'MARKET_ID[MARKET]',[SUPPLEMENT_CAT_CT_PRODUCTS].[NAME] as 'NAME',YEAR([CPL_Booking_Agency_CT_BOOKINGS].[STG_UPDATED_DATE]) as 'Year_Of_STG_UPDATED_DATE[CPL_Booking_Agency]',[COMPONENT_CT_BOOKINGS].[COMPONENT_NO] as 'COMPONENT_NO'  FROM [GFOS].[CT_BOOKINGS].[COMPONENT] [COMPONENT_CT_BOOKINGS] inner join [GFOS].[CT_BOOKINGS].[CPL_Booking_Agency] [CPL_Booking_Agency_CT_BOOKINGS] on [COMPONENT_CT_BOOKINGS].[BOOKING_NO]=[CPL_Booking_Agency_CT_BOOKINGS].[BOOKING_NO] and [COMPONENT_CT_BOOKINGS].[SEASON]=[CPL_Booking_Agency_CT_BOOKINGS].[SEASON] inner join [GFOS].[CT_BOOKINGS].[SERVICE] [SERVICE_CT_BOOKINGS] on [COMPONENT_CT_BOOKINGS].[SEASON]=[SERVICE_CT_BOOKINGS].[SEASON] and [COMPONENT_CT_BOOKINGS].[SERVICE_NO]=[SERVICE_CT_BOOKINGS].[SERVICE_NO] inner join [GFOS].[CT_BOOKINGS].[SERVICE_SUP] [SERVICE_SUP_CT_BOOKINGS] on [SERVICE_CT_BOOKINGS].[SEASON]=[SERVICE_SUP_CT_BOOKINGS].[SEASON] and [SERVICE_CT_BOOKINGS].[CPL_VERSION_NO]=[SERVICE_SUP_CT_BOOKINGS].[VERSION_NO] and [SERVICE_CT_BOOKINGS].[SERVICE_NO]=[SERVICE_SUP_CT_BOOKINGS].[SERVICE_NO] left outer join [GFOS].[CT_PRODUCTS].[SUPPLEMENT_CAT] [SUPPLEMENT_CAT_CT_PRODUCTS] on [SERVICE_SUP_CT_BOOKINGS].[SUP_CAT_ID]=[SUPPLEMENT_CAT_CT_PRODUCTS].[SUP_CAT_ID] inner join [GFOS].[CT_BOOKINGS].[SERVICE_VERSION] [SERVICE_VERSION_CT_BOOKINGS] on [SERVICE_CT_BOOKINGS].[FST_VERSION_NO]=[SERVICE_VERSION_CT_BOOKINGS].[VERSION_NO] and [SERVICE_CT_BOOKINGS].[SEASON]=[SERVICE_VERSION_CT_BOOKINGS].[SEASON] and [SERVICE_CT_BOOKINGS].[SERVICE_NO]=[SERVICE_VERSION_CT_BOOKINGS].[SERVICE_NO] inner join [GFOS].[CT_AGENTS].[AGENCY] [AGENCY_CT_AGENTS] on [CPL_Booking_Agency_CT_BOOKINGS].[AGENCY_NO]=[AGENCY_CT_AGENTS].[AGENCY_NO] inner join [GFOS].[CT_PRODUCTS].[MARKET] [MARKET_CT_PRODUCTS] on [AGENCY_CT_AGENTS].[MARKET_ID]=[MARKET_CT_PRODUCTS].[MARKET_ID] WHERE [SUPPLEMENT_CAT_CT_PRODUCTS].[NAME] IN ('Agent Rebate Distributor','Agent Famil Distributor') GROUP BY [MARKET_CT_PRODUCTS].[MARKET_ID], [SUPPLEMENT_CAT_CT_PRODUCTS].[NAME], YEAR([CPL_Booking_Agency_CT_BOOKINGS].[STG_UPDATED_DATE]), [COMPONENT_CT_BOOKINGS].[COMPONENT_NO]";
		
		String stringQuery = "SELECT [MARKET_CT_PRODUCTS].[MARKET_ID] as 'MARKET_ID[MARKET]',[SUPPLEMENT_CAT_CT_PRODUCTS].[NAME] as 'NAME',YEAR([CPL_Booking_Agency_CT_BOOKINGS].[STG_UPDATED_DATE]) as 'Year_Of_STG_UPDATED_DATE[CPL_Booking_Agency]',[COMPONENT_CT_BOOKINGS].[COMPONENT_NO] as 'COMPONENT_NO'  FROM [GFOS].[CT_BOOKINGS].[COMPONENT] [COMPONENT_CT_BOOKINGS] inner join [GFOS].[CT_BOOKINGS].[CPL_Booking_Agency] [CPL_Booking_Agency_CT_BOOKINGS] on [COMPONENT_CT_BOOKINGS].[BOOKING_NO]=[CPL_Booking_Agency_CT_BOOKINGS].[BOOKING_NO] and [COMPONENT_CT_BOOKINGS].[SEASON]=[CPL_Booking_Agency_CT_BOOKINGS].[SEASON] inner join [GFOS].[CT_BOOKINGS].[SERVICE] [SERVICE_CT_BOOKINGS] on [COMPONENT_CT_BOOKINGS].[SEASON]=[SERVICE_CT_BOOKINGS].[SEASON] and [COMPONENT_CT_BOOKINGS].[SERVICE_NO]=[SERVICE_CT_BOOKINGS].[SERVICE_NO] inner join [GFOS].[CT_BOOKINGS].[SERVICE_SUP] [SERVICE_SUP_CT_BOOKINGS] on [SERVICE_CT_BOOKINGS].[SEASON]=[SERVICE_SUP_CT_BOOKINGS].[SEASON] and [SERVICE_CT_BOOKINGS].[CPL_VERSION_NO]=[SERVICE_SUP_CT_BOOKINGS].[VERSION_NO] and [SERVICE_CT_BOOKINGS].[SERVICE_NO]=[SERVICE_SUP_CT_BOOKINGS].[SERVICE_NO] left outer join [GFOS].[CT_PRODUCTS].[SUPPLEMENT_CAT] [SUPPLEMENT_CAT_CT_PRODUCTS] on [SERVICE_SUP_CT_BOOKINGS].[SUP_CAT_ID]=[SUPPLEMENT_CAT_CT_PRODUCTS].[SUP_CAT_ID] inner join [GFOS].[CT_BOOKINGS].[SERVICE_VERSION] [SERVICE_VERSION_CT_BOOKINGS] on [SERVICE_CT_BOOKINGS].[FST_VERSION_NO]=[SERVICE_VERSION_CT_BOOKINGS].[VERSION_NO] and [SERVICE_CT_BOOKINGS].[SEASON]=[SERVICE_VERSION_CT_BOOKINGS].[SEASON] and [SERVICE_CT_BOOKINGS].[SERVICE_NO]=[SERVICE_VERSION_CT_BOOKINGS].[SERVICE_NO] inner join [GFOS].[CT_AGENTS].[AGENCY] [AGENCY_CT_AGENTS] on [CPL_Booking_Agency_CT_BOOKINGS].[AGENCY_NO]=[AGENCY_CT_AGENTS].[AGENCY_NO] inner join [GFOS].[CT_PRODUCTS].[MARKET] [MARKET_CT_PRODUCTS] on [AGENCY_CT_AGENTS].[MARKET_ID]=[MARKET_CT_PRODUCTS].[MARKET_ID] WHERE [SUPPLEMENT_CAT_CT_PRODUCTS].[NAME] IN ('Agent Rebate Distributor','Agent Famil Distributor') GROUP BY [MARKET_CT_PRODUCTS].[MARKET_ID], [SUPPLEMENT_CAT_CT_PRODUCTS].[NAME], YEAR([CPL_Booking_Agency_CT_BOOKINGS].[STG_UPDATED_DATE]), [COMPONENT_CT_BOOKINGS].[COMPONENT_NO] ORDER BY [MARKET_CT_PRODUCTS].[MARKET_ID], [SUPPLEMENT_CAT_CT_PRODUCTS].[NAME]";
		
		
		try (ResultSet resultSet = getResultSet(stringQuery)) {
			
			rsMetaData = resultSet.getMetaData();
			//document = new Document();
			document = new Document(PageSize.A2.rotate());
			
			PdfWriter writer = PdfWriter.getInstance(document, new FileOutputStream(new File(dest)));
			document.open();
			
			float[] columnWidths = new float[rsMetaData.getColumnCount()];
			int rsColumnCount = rsMetaData.getColumnCount();
			
			int sharedColWidth = 523/rsColumnCount;
			
			// headerCell properties			
			int titleFontSize = 20;
			int headerColumnFontSize = 14;
			
			// dataCell properties 
			int dataCellFontSize = 14;
			float dataPCelHeight = CommonConstants.PCELL_FIXED_HEIGHT;
			
			
			
			// Color properties 
			BaseColor borderBaseColor = new BaseColor(61, 95, 130);
			BaseColor headerSideborderColor = new BaseColor(255, 255, 255);
			BaseColor headerBaseBgColor = new BaseColor(74, 111, 146);
			
			
			int limitRowsPerPg = 18;
			
			
			for (int i = 0; i < rsColumnCount; i++) {
				columnWidths[i] = sharedColWidth; // TODO : after column style formatting implementation we will get this input from UI. And it will be column width w.r.t data
			}
			
			
			PdfPTable table = getNewPdfPTable(columnWidths,titleFontSize,headerColumnFontSize,rsColumnCount,borderBaseColor,headerSideborderColor,headerBaseBgColor,rsMetaData);
			PdfPTable headerTable = null; 
			
			// DATA CELLS Portion 
			Map<String, Integer> columnNamesTypes = new HashMap<String, Integer>();
			
			for (int columnIndex = 1; columnIndex <= rsColumnCount; columnIndex++) {
				columnNamesTypes.put(rsMetaData.getColumnLabel(columnIndex),rsMetaData.getColumnType(columnIndex));
			}
			
			
			Font dataCellFont = new Font(FontFamily.HELVETICA, dataCellFontSize, Font.NORMAL,GrayColor.BLACK);
			PdfPCell dataPCell = null;
			int currentRowsCntPerPg = 0;
			PdfContentByte canvas = writer.getDirectContent();
			String[] prevRowValue = new String[rsColumnCount];
			
			while (resultSet.next()) {
				currentRowsCntPerPg++;
				for (int i = 1; i <= rsColumnCount; i++) {
					String value = ExcelUtils.getValue(rsMetaData.getColumnLabel(i), columnNamesTypes,resultSet);
					//resultSet.getRow()
					/*if (table.getLastCompletedRowIndex() > 0 && i == 1 && value.equals(
							table.getRow(table.getLastCompletedRowIndex()).getCells()[i-1].getPhrase().getContent())) {
						value = "";
					}*/
					
					if (table.getLastCompletedRowIndex() > 0 && i == 1
							&& ( value.equals(prevRowValue[i])  || value.equals(table.getRow(table.getLastCompletedRowIndex()).getCells()[i - 1].getPhrase().getContent()))) {
						prevRowValue[i] = value;
						value = "";
					}
					/*else if (table.getLastCompletedRowIndex() > 0 && i == 2
							&& ( value.equals(prevCellValue)  || value.equals(table.getRow(table.getLastCompletedRowIndex()).getCells()[i - 1].getPhrase().getContent()))) {
						prevCellValue = value;
						value = "";
					}*/
					
					
					dataPCell = new PdfPCell(new Phrase(value == null ? "null" : value, dataCellFont));
					dataPCell.setFixedHeight(dataPCelHeight);
					dataPCell.setBackgroundColor(GrayColor.GRAYWHITE);
					dataPCell.setHorizontalAlignment(com.itextpdf.text.Element.ALIGN_CENTER);
					if (value.equals("")) {
						dataPCell.setBorder(Rectangle.LEFT | Rectangle.RIGHT);
					} else {
						dataPCell.setBorderColorBottom(borderBaseColor);
						dataPCell.setBorderColorTop(borderBaseColor);
					}
					
					dataPCell.setBorderColorLeft(borderBaseColor);
					dataPCell.setBorderColorRight(borderBaseColor);
					
					dataPCell.setHorizontalAlignment(PdfPCell.ALIGN_LEFT);
					dataPCell.setVerticalAlignment(PdfPCell.ALIGN_TOP);
					table.addCell(dataPCell);
				}
				
				if (currentRowsCntPerPg == limitRowsPerPg) {
					headerTable = getNewHeaderPdfPTable(null,titleFontSize,headerColumnFontSize,rsColumnCount,borderBaseColor,headerSideborderColor,headerBaseBgColor,rsMetaData);
					headerTable.writeSelectedRows(0, -1, (document.getPageSize().getWidth()/2) - 100, document.top(), canvas);
					
					table.writeSelectedRows(0, -1, document.left() + 50, (float) (0.75 * document.top()), canvas);
					
					document.newPage();
					table = getNewPdfPTable(columnWidths,titleFontSize,headerColumnFontSize,rsColumnCount,borderBaseColor,headerSideborderColor,headerBaseBgColor,rsMetaData);
					
					currentRowsCntPerPg = 0;
				}
			}
			//table.setHorizontalAlignment(Element.ALIGN_LEFT);
			
			
			//table.writeSelectedRows(0, -1, document.left() + 50, (float) (0.75 * document.top()), canvas);
			//table.writeSelectedRows(0, -1, document.right() - 800, document.top(), canvas);
			//table.writeSelectedRows(0, -1, document.left() - table.getTotalWidth(), document.bottom(), canvas);
			//table.writeSelectedRows(0, -1, 150, document.left(), canvas);
			/*document.newPage();
			table.writeSelectedRows(0, -1, document.left() + 50, (float) (0.75 * document.top()), canvas);*/
			//document.add(table);
			document.close();
		} catch (SQLException | DocumentException | FileNotFoundException e) {
			System.out.println("Exception occured : "+e.getMessage());
		}
	}
	
	
	public ResultSet getResultSet(String stringQuery) {
		ResultSet rs = null;
		try {
			Class.forName("com.microsoft.sqlserver.jdbc.SQLServerDriver");
			String url = "jdbc:sqlserver://ggk-wrl-exp-002:1433;databaseName=GFOS;user=saa;password=Welcome@123";
			Connection con = DriverManager.getConnection(url);
			Statement s1 = con.createStatement();
			rs = s1.executeQuery(stringQuery);
		} catch (Exception e) {
			e.printStackTrace();
		}
		return rs;
	}
	
	private PdfPTable getNewPdfPTable(float[] columnWidths, int titleFontSize, int headerColumnFontSize,
			int rsColumnCount, BaseColor borderBaseColor, BaseColor headerSideborderColor, BaseColor headerBaseBgColor,
			ResultSetMetaData rsMetaData) throws SQLException {

		PdfPTable table = new PdfPTable(columnWidths);
		table.getDefaultCell().setUseAscender(true);
		table.getDefaultCell().setUseDescender(true);
		/*Font font = new Font(FontFamily.HELVETICA, titleFontSize, Font.NORMAL, GrayColor.GRAYWHITE);
		PdfPCell cell = new PdfPCell(new Phrase("ExploraBI Report", font));
		// cell.setBackgroundColor(GrayColor.GRAYBLACK);
		cell.setBackgroundColor(new BaseColor(74, 111, 146));
		cell.setHorizontalAlignment(com.itextpdf.text.Element.ALIGN_CENTER);
		cell.setColspan(rsColumnCount - 1);
		cell.setBorderColorTop(borderBaseColor);
		cell.setBorderColorBottom(borderBaseColor);
		cell.setBorderColorLeft(headerSideborderColor);
		cell.setBorderColorRight(headerSideborderColor);
		table.addCell(cell);*/
		table.getDefaultCell().setBackgroundColor(headerBaseBgColor);

		// table.setSplitRows(splitRows);

		// HEADER CELLS Portion
		Font headerCellFont = new Font(FontFamily.HELVETICA, headerColumnFontSize, Font.NORMAL, GrayColor.GRAYWHITE);
		PdfPCell headerPCell = null;

		for (int i = 1; i <= rsColumnCount; i++) { // here starting with 2 bcz rsMetaData starts from 0 index & 1 index is RowNum. Both are not reqrd so skipping. 
												   //from 2nd index actual required columns starts. So we want to access actual req columns
			headerPCell = new PdfPCell(new Phrase(rsMetaData.getColumnName(i), headerCellFont));
			headerPCell.setBackgroundColor(headerBaseBgColor);
			/*
			 * headerPCell.setUseVariableBorders(true);
			 * headerPCell.setBorderColorTop(borderBaseColor);
			 * headerPCell.setBorderColorBottom(borderBaseColor);
			 * headerPCell.setBorderColorLeft(headerSideborderColor);
			 * headerPCell.setBorderColorRight(headerSideborderColor);
			 */
			headerPCell.setHorizontalAlignment(com.itextpdf.text.Element.ALIGN_CENTER);
			headerPCell.setFixedHeight(CommonConstants.PCELL_FIXED_HEIGHT);
			table.addCell(headerPCell);
		}

		table.setHeaderRows(3);
		table.setFooterRows(1);
		table.getDefaultCell().setBackgroundColor(GrayColor.GRAYWHITE);
		table.getDefaultCell().setHorizontalAlignment(com.itextpdf.text.Element.ALIGN_CENTER);
		table.setTotalWidth(1200);
		table.setWidthPercentage(80);
		return table;
	}
	
	private PdfPTable getNewHeaderPdfPTable(float[] columnWidths, int titleFontSize, int headerColumnFontSize,
			int rsColumnCount, BaseColor borderBaseColor, BaseColor headerSideborderColor, BaseColor headerBaseBgColor,
			ResultSetMetaData rsMetaData) throws SQLException {

		PdfPTable table = new PdfPTable(1); //columnWidths
		Font font = new Font(FontFamily.HELVETICA, 30, Font.NORMAL, headerBaseBgColor);
		PdfPCell cell = new PdfPCell(new Phrase("Explora-BI", font));
		cell.setHorizontalAlignment(com.itextpdf.text.Element.ALIGN_CENTER);
		cell.setBorder(Rectangle.NO_BORDER);
		table.addCell(cell);
		
		font = new Font(FontFamily.HELVETICA, 15, Font.NORMAL, headerBaseBgColor);
		font.setStyle(2);
		cell = new PdfPCell(new Phrase("Reporting with intelligence", font));
		cell.setHorizontalAlignment(com.itextpdf.text.Element.ALIGN_CENTER);
		cell.setBorder(Rectangle.NO_BORDER);
		cell.setFixedHeight(CommonConstants.PCELL_FIXED_HEIGHT);
		table.addCell(cell);
		
		table.setTotalWidth(200);
		table.getDefaultCell().setBorder(Rectangle.NO_BORDER);
		return table;
	}
}