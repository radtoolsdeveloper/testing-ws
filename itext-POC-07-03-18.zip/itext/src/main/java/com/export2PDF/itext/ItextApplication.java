package com.export2PDF.itext;

import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ItextApplication {

	/*public static void main(String[] args) throws IOException, DocumentException {
		SpringApplication.run(ItextApplication.class, args);
		new IncompleteTable().createPdf();
		//new D00_XHTML().createPdf();
		SpringApplication.run(ItextApplication.class, args);
	}*/

}
