package com.export2PDF.itext.common;

public interface CommonConstants {
	public static final String SRC = "C:/Users/pradeep.repala/Desktop/results/tables/column_width_example_snippet.pdf";
	public static final String MANIP_DEST = "C:/Users/pradeep.repala/Desktop/results/tables/column_width_example_snippet_75p.pdf";
	public static final String DEST = "C:/Users/pradeep.repala/Desktop/results/tables/column_width_example_snippet.pdf";
	int PCELL_FIXED_HEIGHT = 40;
}
